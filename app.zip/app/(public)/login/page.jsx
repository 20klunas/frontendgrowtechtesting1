"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import Cookies from "js-cookie";
import { useAuth } from "../../hooks/useAuth";
import { Eye, EyeOff } from "lucide-react";
import { publicFetch } from "../../lib/publicFetch";

export default function LoginPage() {

  const router = useRouter();
  const API = process.env.NEXT_PUBLIC_API_URL;

  const { user, login, loading } = useAuth();

  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [showPassword,setShowPassword] = useState(false);
  const [submitting,setSubmitting] = useState(false);

  const [popup,setPopup] = useState({
    open:false,
    type:"info",
    message:""
  });

  useEffect(()=>{

    if(loading) return

    if(user){

      if(user.role==="admin"){
      router.replace("/admin/dashboard")
      }else{
      router.replace("/customer")
      }

    }

  },[user,loading])

  const handleLogin = async (e)=>{
    e.preventDefault();

    try{

      setSubmitting(true);

      if(!API){
        throw new Error("NEXT_PUBLIC_API_URL belum diset");
      }

      const res = await publicFetch("/api/v1/auth/login",{
        method:"POST",
        body:JSON.stringify({email,password})
      });

      if(res?.data?.requires_2fa){
        router.push(`/verify-otp?challenge_id=${res.data.challenge_id}`);
        return;
      }

      const token = res?.data?.token;
      const userData = res?.data?.user;

      if(!token || !userData){
        throw new Error("Token atau user tidak ditemukan");
      }

      Cookies.set("token",token,{
        path:"/",
        sameSite:"lax"
      });

      login(userData,token);

      if(userData.role === "admin"){
        router.replace("/admin/dashboard");
      }else{
        router.replace("/customer");
      }

    }catch(err){

      setPopup({
        open:true,
        type:"error",
        message:err?.message || "Login gagal"
      });

    }finally{
      setSubmitting(false);
    }
  };

  const handleGoogleLogin = ()=>{

    if(!API){
      setPopup({
        open:true,
        type:"error",
        message:"API belum dikonfigurasi"
      });
      return;
    }

    window.location.href = `${API}/api/v1/auth/google/redirect`;
  };

  const handleDiscordLogin = ()=>{

    if(!API){
      setPopup({
        open:true,
        type:"error",
        message:"API belum dikonfigurasi"
      });
      return;
    }

    window.location.href = `${API}/api/v1/auth/discord/redirect`;
  };

  return (
    <main className="min-h-[calc(100vh-80px)] flex items-center justify-center px-4 pt-16">

      <div className="w-full max-w-md rounded-2xl border border-purple-400/60 bg-black p-8">

        {popup.open && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70">

            <div className="w-[380px] rounded-2xl border border-purple-500 bg-black p-6 shadow-xl">

              <h2 className="text-lg font-semibold text-purple-300 mb-3">
                Pemberitahuan !
              </h2>

              <p className="text-sm text-gray-300 mb-6">
                {popup.message}
              </p>

              <button
                onClick={()=>setPopup({...popup,open:false})}
                className="w-full rounded-lg bg-purple-600 py-2 font-semibold hover:bg-purple-700 transition"
              >
                Tutup
              </button>

            </div>

          </div>
        )}

        <h1 className="text-center text-2xl font-semibold text-purple-300 mb-6">
          Login
        </h1>

        <form className="space-y-4" onSubmit={handleLogin}>

          <div>
            <label className="text-sm text-purple-300">Email</label>

            <input
              type="email"
              value={email}
              onChange={(e)=>setEmail(e.target.value)}
              placeholder="growtech@email.com"
              required
              className="mt-1 w-full rounded-lg border border-purple-400/50 bg-black px-4 py-2 text-white outline-none focus:border-purple-500"
            />
          </div>

          <div>
            <label className="text-sm text-purple-300">Password</label>

            <div className="relative mt-1">

              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e)=>setPassword(e.target.value)}
                placeholder="********"
                required
                className="w-full rounded-lg border border-purple-400/50 bg-black px-4 py-2 pr-10 text-white outline-none focus:border-purple-500"
              />

              <button
                type="button"
                onClick={()=>setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-purple-400 hover:text-purple-200"
              >
                {showPassword ? <EyeOff size={18}/> : <Eye size={18}/>}
              </button>

            </div>
          </div>

          <div className="text-right">
            <a
              href="/forgot-password"
              className="text-sm text-purple-400 hover:underline"
            >
              Lupa password?
            </a>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="mt-4 w-full rounded-xl bg-[#2B044D] py-3 font-semibold text-white transition hover:bg-[#3a0a6a] disabled:opacity-50"
          >
            {submitting ? "Logging in..." : "Login"}
          </button>

        </form>

        <p className="mt-6 text-center text-sm text-gray-400">
          Belum punya akun?{" "}
          <a href="/register" className="text-purple-400 hover:underline">
            Register
          </a>
        </p>

        <div className="mt-6 border-t border-purple-400/30 pt-4 text-center">

          <p className="mb-3 text-sm text-gray-400">
            Masuk dengan
          </p>

          <div className="flex gap-3">

            <button
              type="button"
              onClick={handleGoogleLogin}
              className="flex flex-1 items-center justify-center gap-2 rounded-lg border border-purple-400/50 py-2 text-sm hover:bg-purple-400/10"
            >
              <Image src="/icons/google-icon.svg" alt="Google" width={18} height={18}/>
              Google
            </button>

            <button
              type="button"
              onClick={handleDiscordLogin}
              className="flex flex-1 items-center justify-center gap-2 rounded-lg border border-purple-400/50 py-2 text-sm hover:bg-purple-400/10"
            >
              <Image src="/icons/discord-icon.svg" alt="Discord" width={18} height={18}/>
              Discord
            </button>

          </div>

        </div>

      </div>

    </main>
  );
}