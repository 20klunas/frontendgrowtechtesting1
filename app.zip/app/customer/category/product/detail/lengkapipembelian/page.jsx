"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { authFetch } from "../../../../../lib/authFetch";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import useCheckoutAccess from "../../../../../hooks/useCheckoutAccess";

const API = process.env.NEXT_PUBLIC_API_URL;

export default function StepTwo() {
  const [checkout, setCheckout] = useState(null);
  // const [qty, setQty] = useState(1);
  const [walletBalance, setWalletBalance] = useState(0);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  // const [patchingQty, setPatchingQty] = useState(false);
  const { loading: accessLoading, allowed, message } = useCheckoutAccess();

  const router = useRouter();

  const handleGoPayment = () => {
    router.push("/customer/category/product/detail/lengkapipembelian/methodpayment");
  };

  useEffect(() => {
    fetchCheckout();
    fetchWallet();
    fetchProducts();
  }, []);

  // ================= FETCH CHECKOUT =================
  const fetchCheckout = async () => {
    try {
      const json = await authFetch("/api/v1/cart/checkout");

      if (json.success) {
        setCheckout(json.data);
        // setQty(json.data.items?.[0]?.qty || 1);
      }
    } catch (err) {
      console.warn("Checkout preview failed:", err.message);
      setCheckout(null);
    } finally {
      setLoading(false);
    }
  };

  // ================= FETCH WALLET =================
  const fetchWallet = async () => {
    try {
      const json = await authFetch("/api/v1/wallet/summary");

      if (json.success) {
        setWalletBalance(json.data.wallet?.balance ?? 0);
      }
    } catch (err) {
      console.warn("Wallet fetch failed:", err.message);
      setWalletBalance(0);
    }
  };

  // ================= FETCH PRODUCTS (CACHED) =================
  const fetchProducts = async () => {
    try {
      const cached = sessionStorage.getItem("products_cache");

      if (cached) {
        setProducts(JSON.parse(cached));
        return;
      }

      const res = await fetch(`${API}/api/v1/products`);

      const contentType = res.headers.get("content-type");
      if (!contentType?.includes("application/json")) {
        const text = await res.text();
        console.error("Non-JSON response:", text);
        throw new Error("API did not return JSON");
      }

      const json = await res.json();

      if (json.success) {
        const data = json?.data?.data || [];
        setProducts(data);
        sessionStorage.setItem("products_cache", JSON.stringify(data));
      }
    } catch (err) {
      console.error("Failed fetch products:", err);
      setProducts([]);
    }
  };

  // ================= UPDATE QTY =================
  const updateQty = async (newQty) => {
    if (!checkout || patchingQty) return;

    const item = checkout.items[0];
    const stockAvailable = item.stock_available ?? 0;


    if (newQty < 1 || newQty > stockAvailable) return;

    const oldQty = qty;

    setQty(newQty);
    setPatchingQty(true);

    try {
      const json = await authFetch(`/api/v1/cart/items/${item.id}`, {
        method: "PATCH",
        body: JSON.stringify({
          qty: newQty,
        }),
      });

      if (json.success) {
        await fetchCheckout(); // refresh checkout
        window.dispatchEvent(new Event("cart-updated"));
      }

    } catch (err) {
      console.error("Update qty failed:", err.message);
      setQty(oldQty);
    } finally {
      setPatchingQty(false);
    }
  };


  // ================= SKELETON LOADING =================
  if (loading) {
    return (
      <section className="max-w-5xl mx-auto px-6 py-12 text-white animate-pulse">
        <div className="h-8 w-64 bg-purple-900/40 rounded mb-10" />
        <div className="h-40 bg-purple-900/20 rounded-2xl mb-6" />
        <div className="h-20 bg-purple-900/20 rounded-2xl mb-6" />
        <div className="h-12 bg-purple-900/20 rounded-xl mb-6" />
      </section>
    );
  }

  if (!checkout || !checkout.items?.length) {
    return (
      <section className="max-w-5xl mx-auto px-6 py-12 text-white text-center">
        <p className="text-gray-400">Checkout kosong</p>

        <Link
          href="/customer/category/product/detail/cart"
          className="mt-4 inline-block px-6 py-3 rounded-xl bg-purple-700 hover:bg-purple-600 transition"
        >
          Kembali ke Keranjang
        </Link>
      </section>
    );
  }

  const item = checkout.items[0];
  const qty = item.qty ?? 1;
  const product = item.product;
  const unitPrice = item.unit_price ?? 0;
  const stockAvailable = item.stock_available ?? 0;

  // ================= IMAGE MATCH =================
  const matchedProduct = products.find(p => p.id === product?.id);

  const productImage =
    matchedProduct?.subcategory?.image_url ||
    matchedProduct?.image_url ||
    product?.subcategory?.image_url ||
    product?.image_url ||
    "/placeholder.png";

  const subtotal = checkout.summary?.subtotal ?? 0;
  const discount = checkout.summary?.discount_total ?? 0;
  const taxPercent = checkout.summary?.tax_percent ?? 0;
  const taxAmount = checkout.summary?.tax_amount ?? 0;
  const total = checkout.summary?.total ?? 0;

  if (accessLoading) {
    return (
      <section className="max-w-5xl mx-auto px-6 py-12 text-white">
        <p className="text-gray-400">Checking checkout access...</p>
      </section>
    );
  }

  if (!allowed) {
    return (
      <section className="max-w-5xl mx-auto px-6 py-12 text-white text-center">
        <h2 className="text-2xl font-semibold mb-3">
          Checkout Sedang Maintenance
        </h2>

        <p className="text-gray-400 mb-6">
          {message || "Silakan coba lagi nanti."}
        </p>

        <Link
          href="/customer/category"
          className="px-6 py-3 rounded-xl bg-purple-700 hover:bg-purple-600"
        >
          Kembali ke Katalog
        </Link>
      </section>
    );
  }

  return (
    <section className="max-w-5xl mx-auto px-6 py-10 text-white">
      <h1 className="text-3xl font-bold mb-10">
        Lengkapi Data Pembelian
      </h1>

      {/* ================= PRODUK ================= */}
      <div className="rounded-2xl border border-purple-800 bg-black p-6 mb-6">
        <p className="text-sm text-gray-400 mb-4">Produk Yang Dipilih</p>

        <div className="flex items-center gap-4">
          <div className="relative h-16 w-16 rounded-xl overflow-hidden border border-purple-700">
            <Image
              src={productImage}
              fill
              alt={product?.name}
              className="object-cover"
            />
          </div>

          <div className="flex-1">
            <p className="font-medium">{product?.name}</p>
            <p className="text-sm text-gray-400">
              Rp {unitPrice.toLocaleString()} / unit
            </p>
          </div>

          <div className="text-right">
            <p className="text-sm text-gray-400">Total</p>
            <p className="text-purple-400 font-semibold">
              Rp {(unitPrice * qty).toLocaleString()}
            </p>
          </div>
        </div>

        {/* ================= QTY ================= */}
        <div className="mt-6 flex items-center justify-between">
          <span className="text-sm text-gray-400">
            Jumlah Pembelian
          </span>

          <div className="px-4 py-1 rounded-lg bg-purple-900/30">
            {qty} Unit
          </div>
        </div>
        <p className="text-xs text-yellow-500 mt-2">
            Catatan: Jumlah pembelian tidak dapat diubah di halaman ini. 
            Untuk mengubah jumlah yang dibeli silakan ke keranjang atau masukkan produk ke keranjang dahulu.
        </p>
      </div>

      {/* ================= SALDO ================= */}
      <div className="rounded-2xl border border-purple-800 bg-black p-6 mb-8 flex justify-between items-center">
        <div>
          <p className="text-sm text-gray-300">Saldo Wallet</p>
          <p className="text-xs text-gray-500">
            Saldo Tersedia: Rp {walletBalance.toLocaleString("id-ID")}
          </p>
        </div>

        <Link
          href="/customer/topup"
          className="px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-600 text-sm"
        >
          Top Up
        </Link>
      </div>

      {/* ================= BUTTONS ================= */}
      <div className="flex gap-4 mb-8">
        <Link
          href="/customer/category"
          className="flex-1 text-center py-3 rounded-xl border border-purple-700 hover:bg-purple-700/20"
        >
          Kembali
        </Link>

        <button
          onClick={handleGoPayment}
          className="flex-1 py-3 rounded-xl bg-purple-700 hover:bg-purple-600 font-semibold"
        >
          Lanjut Ke Pembayaran →
        </button>
      </div>

      {/* ================= RINGKASAN ================= */}
      <div className="rounded-2xl border border-purple-800 bg-black p-6">
        <h3 className="font-semibold mb-4">Ringkasan</h3>

        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-400">Harga Unit</span>
            <span>Rp {unitPrice.toLocaleString()}</span>
          </div>

          <div className="flex justify-between">
            <span className="text-gray-400">Jumlah</span>
            <span>{qty}x</span>
          </div>

          <div className="flex justify-between">
            <span className="text-gray-400">Sub Total</span>
            <span>Rp {subtotal.toLocaleString()}</span>
          </div>

          <div className="flex justify-between">
            <span className="text-gray-400">Tax ({taxPercent}%)</span>
            <span>Rp {taxAmount.toLocaleString()}</span>
          </div>

          <div className="flex justify-between">
            <span className="text-gray-400">Diskon</span>
            <span>Rp {discount.toLocaleString()}</span>
          </div>

          <div className="border-t border-purple-800 pt-3 flex justify-between font-semibold">
            <span>Total</span>
            <span className="text-purple-400">
              Rp {total.toLocaleString()}
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}